const mongoose = require("mongoose");

// Task schema
const TaskSchema = new mongoose.Schema({
  taskName: {
    type: String,
    required: true,
  },
  responsibility: {
    type: String,
    required: true,
  },
  deadline: {
    type: Date,
    required: true,
  },
});

module.exports = mongoose.model("Task", TaskSchema);
