const mongoose = require("mongoose");

// Employee subdocument schema
const EmployeeSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
});

// Organization schema
const OrganizationSchema = new mongoose.Schema({
    organizationname: {
    type: String,
    required: true,
  },
  employees: {
    type: [EmployeeSchema],
    required: true,
  },
});


module.exports = mongoose.model("Organization", OrganizationSchema);
