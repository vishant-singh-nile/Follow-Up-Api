const mongoose = require("mongoose");
const Organization = require("../models/Organization");
const Task = require("../models/Task");

const getAllProducts =async(req,res) => {

    const myapi = await Organization.find(req.query)
       res.status(200).json({ myapi });
};

const getAllProductstesting =async(req,res) => {
    res.status(200).json({msg : "hello form NILE company"});
};

const createTask = async (req, res) => {
    const { taskName, responsibility, deadline } = req.body;
  
    try {
      const task = new Task({ taskName, responsibility, deadline });
      await task.save();
      res.status(201).json({ task });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Error saving task" });
    }
  };

// all task
  const getAllTask = async (req, res) => {
    try {
      const tasks = await Task.find(); 
      res.status(200).json({ tasks }); 
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Error fetching tasks" });
    }
  };



  //read one 
const getTaskById = async (req, res) => {
    try {
      const task = await Task.findById(req.params.id);
      if (!task) return res.status(404).json({ message: "Task not found" });
      res.json(task);
    } catch (error) {
      res.status(500).json({ error: "Error fetching task" });
    }
  };
  

  // PUT update
  const updateTask = async (req, res) => {
    const { id } = req.params;
  
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(400).json({ error: "Invalid task ID format" });
    }
  
    try {
      const updated = await Task.findByIdAndUpdate(id, req.body, { new: true });
      if (!updated) return res.status(404).json({ message: "Task not found" });
      res.json(updated);
    } catch (error) {
      console.error("Update error:", error);
      res.status(500).json({ error: "Error updating task" });
    }
  };
  
  
  

  // DELETE 
const deleteTask = async (req, res) => {
    try {
      const deleted = await Task.findByIdAndDelete(req.params.id);
      if (!deleted) return res.status(404).json({ message: "Task not found" });
      res.json({ message: "Task deleted" });
    } catch (error) {
      res.status(500).json({ error: "Error deleting task" });
    }
  };
  


module.exports= { getAllProducts,getAllProductstesting,createTask,getAllTask,getTaskById,updateTask,deleteTask};