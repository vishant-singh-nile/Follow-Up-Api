require("dotenv").config();
const connectDB = require("./Database/Connect");
const Organization = require("./models/Organization")

const ProductJson =require("./Products.json")

const start = async() => {
    try{
        await connectDB(process.env.MONGODB_URL);
        await Organization.deleteMany();
        await Organization.create(ProductJson);
        console.log("success");
    }
    catch(error){
        console.log(error)
    }
};


start();