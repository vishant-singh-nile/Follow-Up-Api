const express = require ("express");
const router = express.Router();


// import all file
const {getAllProducts,getAllProductstesting, createTask,getAllTask,getTaskById,updateTask,deleteTask} = require("../controllers/Product")

// call all routes
router.route("/").get(getAllProducts);
router.route("/testing").get(getAllProductstesting);
router.route("/Task").post(createTask);
router.route("/AllTask").get(getAllTask);
router.route("/Task/:id").get(getTaskById);     // Read One
router.route("/Task/:id").put(updateTask);      // Update
router.route("/Task/:id").delete(deleteTask);  // delete

// export routes
module.exports = router; 