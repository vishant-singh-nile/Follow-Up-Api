// index.js
const express = require('express');
const connectDB = require('./Database/Connect');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const Task = require('./models/Task');
const bcrypt = require('bcrypt');
const hashedPassword = bcrypt.hashSync('secret123', 10);
const dotenv = require('dotenv');
dotenv.config();
const admin = require('firebase-admin');

const serviceAccount = require('./config/firebase-service-account.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});




const PORT = process.env.PORT || 3000;
app.use(express.json());

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());


// Connect to database
connectDB(process.env.MONGODB_URL); 

// Routes
const Products_routes = require("./routes/Product");
const verifyToken = require('./VerifyToken');

const users = [
  {
    username: 'admin',
    password: hashedPassword
  }
];

// Public Route
app.get('/', (req, res) => {
  res.send('Welcome to my API!');
});

// html form
app.get('/Task', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'form.html'));
});



// Example: Login route (token generate karta hai)
const jwt = require('jsonwebtoken');

app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  const user = users.find(u => u.username === username);
  if (!user) {
    return res.status(401).json({ message: 'Invalid username or password' });
  }

  const isMatch = await bcrypt.compare(password, user.password);
  if (!isMatch) {
    return res.status(401).json({ message: 'Invalid username or password' });
  }

  const token = jwt.sign(
    { username: user.username },
    process.env.JWT_SECRET,
    { expiresIn: '90d' }
  );

  res.json({ token });
});



// Protected Routes (token required)  
app.use("/api/Organization", verifyToken, Products_routes);

// Route to handle form submission
app.post('/submit', async (req, res) => {
  const { taskName, responsibility, deadline } = req.body;

  try {
    const task = new Task({ taskName, responsibility, deadline });

    // Save task to DB
    await task.save();

    // Now send a notification to the assigned user
    const user = await Task.findOne({ username: responsibility }); // Assuming 'responsibility' is the username or user identifier

    if (user && user.fcmToken) {
      const message = {
        notification: {
          title: 'New Task Assigned',
          body: `You have been assigned a new task: ${taskName}`,
        },
        token: user.fcmToken, // The FCM token of the assigned user
      };

      // Send the notification via Firebase
      await admin.messaging().send(message);
      console.log('Notification sent successfully');
    } else {
      console.log('No FCM token found for this user');
    }

    res.send('Task saved and notification sent successfully!');
  } catch (error) {
    console.error(error);
    res.status(500).send('Error saving task and sending notification');
  }
});


// get task data 
app.get('/Alltask', async (req, res) => {
  try {
    const tasks = await Task.find();
    res.json(tasks);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch tasks', error: err });
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
